import os
import requests
from dotenv import load_dotenv
from fastmcp import FastMCP

# -------------------------------
# LOAD ENV
# -------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(dotenv_path=os.path.join(BASE_DIR, ".env"))

mcp = FastMCP(name="jira-tools")

JIRA_BASE = os.getenv("JIRA_BASE")
EMAIL = os.getenv("JIRA_EMAIL")
TOKEN = os.getenv("JIRA_API_TOKEN")
PROJECT = os.getenv("JIRA_PROJECT_KEY")

# Validate env
if not all([JIRA_BASE, EMAIL, TOKEN, PROJECT]):
    raise ValueError("Missing environment variables in .env")

auth = (EMAIL, TOKEN)

headers = {
    "Accept": "application/json",
    "Content-Type": "application/json"
}

# -------------------------------
# CREATE ISSUE (SAFE VERSION)
# -------------------------------
@mcp.tool(name="create_jira_issue")
def create_issue(
    summary: str,
    description: str = "",
    issue_type: str = "Task"
):
    """Create a Jira issue (safe minimal payload)"""

    url = f"{JIRA_BASE}/rest/api/3/issue"

    payload = {
        "fields": {
            "project": {"key": PROJECT},
            "summary": summary,
            "issuetype": {"name": issue_type}
        }
    }
    if description:
        payload["fields"]["description"] = {
            "type": "doc",
            "version": 1,
            "content": [
                {
                    "type": "paragraph",
                    "content": [
                        {"type": "text", "text": description}
                    ]
                }
            ]
        }

    r = requests.post(url, json=payload, auth=auth, headers=headers)

    if r.status_code == 401:
        return {
            "error": (
                "Jira authentication failed. Verify JIRA_EMAIL and "
                "JIRA_API_TOKEN in .env."
            )
        }

    if r.status_code != 201:
        print("CREATE ERROR:", r.status_code, r.text)
        return {"error": r.text}

    return r.json()


# -------------------------------
# UPDATE ISSUE
# -------------------------------
@mcp.tool(name="update_jira_issue")
def update_issue(issue_key: str, summary: str):
    """Update Jira issue summary"""

    url = f"{JIRA_BASE}/rest/api/3/issue/{issue_key}"

    payload = {"fields": {"summary": summary}}

    r = requests.put(url, json=payload, auth=auth, headers=headers)

    if r.status_code not in [200, 204]:
        print("UPDATE ERROR:", r.status_code, r.text)
        return {"error": r.text}

    return {"status": "updated"}


# -------------------------------
# ADD COMMENT
# -------------------------------
@mcp.tool(name="add_jira_comment")
def add_comment(issue_key: str, comment: str):
    """Add comment to Jira issue"""

    url = f"{JIRA_BASE}/rest/api/3/issue/{issue_key}/comment"

    payload = {
        "body": comment  # simple format (safe)
    }

    r = requests.post(url, json=payload, auth=auth, headers=headers)

    if r.status_code != 201:
        print("COMMENT ERROR:", r.status_code, r.text)
        return {"error": r.text}

    return {"status": "comment added"}


# -------------------------------
# MOVE ISSUE
# -------------------------------
@mcp.tool(name="move_jira_issue")
def move_issue(issue_key: str, status: str):
    """Move issue to new status"""

    url = f"{JIRA_BASE}/rest/api/3/issue/{issue_key}/transitions"

    # Get transitions
    r = requests.get(url, auth=auth, headers=headers)

    if r.status_code != 200:
        print("TRANSITION FETCH ERROR:", r.status_code, r.text)
        return {"error": r.text}

    transitions = r.json().get("transitions", [])

    transition_id = None
    for t in transitions:
        if t["name"].lower() == status.lower():
            transition_id = t["id"]
            break

    if not transition_id:
        return {
            "error": f"Status '{status}' not found",
            "available": [t["name"] for t in transitions]
        }

    # Perform transition
    r = requests.post(
        url,
        json={"transition": {"id": transition_id}},
        auth=auth,
        headers=headers
    )

    if r.status_code == 204:
        return {"status": f"{issue_key} moved to {status}"}
    else:
        print("MOVE ERROR:", r.status_code, r.text)
        return {"error": r.text}


# -------------------------------
# START SERVER
# -------------------------------
if __name__ == "__main__":
    print("🚀 Starting Jira MCP Server...")
    mcp.run()
