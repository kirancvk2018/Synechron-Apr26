# Jira MCP for Cursor

## Setup
pip install -r requirements.txt

## Run
python server.py

## Cursor MCP config example
{
  "mcpServers": {
    "jira": {
      "command": "python",
      "args": ["server.py"],
      "cwd": "c:/Users/Administrator/Downloads/jira_mcp_cursor"
    }
  }
}

If Jira returns 401 on `create_jira_issue`, regenerate the API token and verify
`JIRA_EMAIL` + `JIRA_API_TOKEN` in `.env`.
