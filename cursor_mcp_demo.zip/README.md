# Cursor MCP MySQL Demo

## Setup
1. Add DB credentials in .env
2. Install deps:
   pip install -r requirements.txt

## Load Data
python load_data.py

## Run MCP
Open this folder in Cursor and restart Cursor.

## Test Prompt
Use:
"Use MCP tool to calculate commission and update database"
