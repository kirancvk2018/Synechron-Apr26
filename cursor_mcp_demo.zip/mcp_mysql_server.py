import os
import time
import mysql.connector
from mcp.server.fastmcp import FastMCP
from dotenv import load_dotenv

load_dotenv()

mcp = FastMCP("mysql-mcp")

def get_connection():
    return mysql.connector.connect(
        host=os.getenv("DB_HOST"),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
        database=os.getenv("DB_NAME")
    )

@mcp.tool()
def run_query(query: str) -> str:
    print("\n--- MCP TOOL INVOKED ---")
    print("Executing Query:\n", query)
    time.sleep(1)

    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute(query)

        if query.strip().lower().startswith("select"):
            results = cursor.fetchall()
            print("Returned:", results[:5])
            return str(results)
        else:
            conn.commit()
            print("Update committed")
            return "Query executed successfully"

    except Exception as e:
        print("Error:", str(e))
        return str(e)

    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    mcp.run()
