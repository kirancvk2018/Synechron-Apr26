import mysql.connector
import random
import os
from dotenv import load_dotenv

load_dotenv()

conn = mysql.connector.connect(
    host=os.getenv("DB_HOST"),
    user=os.getenv("DB_USER"),
    password=os.getenv("DB_PASSWORD"),
    database=os.getenv("DB_NAME")
)

cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS sales_workday (
    emp_id INT PRIMARY KEY,
    emp_name VARCHAR(100),
    department VARCHAR(50),
    region VARCHAR(50),
    monthly_sales DECIMAL(10,2),
    commission DECIMAL(10,2)
)
""")

names = ["Amit","Priya","Rahul","Sneha","Kiran","Neha"]
regions = ["North","South","East","West"]

data = []
for i in range(1, 101):
    data.append((i, random.choice(names)+str(i), "Sales", random.choice(regions), random.randint(50000,200000), 0))

cursor.executemany("INSERT INTO sales_workday VALUES (%s,%s,%s,%s,%s,%s)", data)

conn.commit()
print("Data Loaded")

cursor.close()
conn.close()
